export class OrderDetails {
    public intent: string;
    public food: string;
    public beverage: string;
}