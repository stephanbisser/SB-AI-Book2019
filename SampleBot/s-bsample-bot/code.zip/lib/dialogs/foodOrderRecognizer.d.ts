import { RecognizerResult, TurnContext } from 'botbuilder';
import { LuisApplication } from 'botbuilder-ai';
export declare class FoodOrderRecognizer {
    private recognizer;
    constructor(config: LuisApplication);
    readonly isConfigured: boolean;
    /**
     * Returns an object with preformatted LUIS results for the bot's dialogs to consume.
     * @param {TurnContext} context
     */
    executeLuisQuery(context: TurnContext): Promise<RecognizerResult>;
    getfoodEntities(result: any): {
        food: any;
    };
    getBeverageEntities(result: any): {
        beverage: any;
    };
}
