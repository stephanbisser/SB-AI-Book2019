import { CancelAndHelpDialog } from './cancelAndHelpDialog';
export declare class OrderDialog extends CancelAndHelpDialog {
    constructor(id: string);
    /**
     * If food type has not been provided, prompt for one.
     */
    private foodStep;
    /**
     * If a beverage has not been provided, prompt for one.
     */
    private beverageStep;
    /**
     * Confirm the information the user has provided.
     */
    private confirmStep;
    /**
     * Complete the interaction and end the dialog.
     */
    private finalStep;
}
