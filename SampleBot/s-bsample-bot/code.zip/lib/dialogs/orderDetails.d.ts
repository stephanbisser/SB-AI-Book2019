export declare class OrderDetails {
    intent: string;
    food: string;
    beverage: string;
}
